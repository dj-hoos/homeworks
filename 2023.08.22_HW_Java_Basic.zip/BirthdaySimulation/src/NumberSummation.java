import java.util.Scanner;

public class NumberSummation {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String userInput;
        do {
            System.out.print("Введите начальное значение диапазона (целое число) или 'quit' для завершения: ");
            userInput = scanner.nextLine();

            if (!userInput.equalsIgnoreCase("quit")) {
                try {
                    int start = Integer.parseInt(userInput);
                    System.out.print("Введите конечное значение диапазона (целое число): ");
                    int end = scanner.nextInt();

                    int sum = 0;
                    for (int i = start; i <= end; i++) {
                        if (i % 2 != 0) {
                            sum += i;
                        }
                    }

                    System.out.println("Сумма всех нечётных чисел в диапазоне [" + start + ", " + end + "] равна: " + sum);
                } catch (NumberFormatException e) {
                    System.out.println("Некорректный ввод. Пожалуйста, введите целое число или 'quit'.");
                }
            }
            scanner.nextLine();
        } while (!userInput.equalsIgnoreCase("quit"));

        System.out.println("Программа завершена.");
    }
}
