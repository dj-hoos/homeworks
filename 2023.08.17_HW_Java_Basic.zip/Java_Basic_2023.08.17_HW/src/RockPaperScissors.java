import java.util.Scanner;
import java.util.Random;

public class RockPaperScissors {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.println("Выберите свой вариант:");
        System.out.println("1. Камень");
        System.out.println("2. Ножницы");
        System.out.println("3. Бумага");

        int userChoice = scanner.nextInt();
        int computerChoice = random.nextInt(3) + 1;

        System.out.println("Ваш выбор: " + getChoiceString(userChoice));
        System.out.println("Выбор компьютера: " + getChoiceString(computerChoice));

        int result = determineWinner(userChoice, computerChoice);
        if (result == 0) {
            System.out.println("Ничья!");
        } else if (result == 1) {
            System.out.println("Вы победили!");
        } else {
            System.out.println("Компьютер победил!");
        }
    }

    public static String getChoiceString(int choice) {
        switch (choice) {
            case 1:
                return "Камень";
            case 2:
                return "Ножницы";
            case 3:
                return "Бумага";
            default:
                return "Недопустимый выбор";
        }
    }

    public static int determineWinner(int userChoice, int computerChoice) {
        if (userChoice == computerChoice) {
            return 0; // Ничья
        } else if ((userChoice == 1 && computerChoice == 2) ||
                (userChoice == 2 && computerChoice == 3) ||
                (userChoice == 3 && computerChoice == 1)) {
            return 1; // Пользователь победил
        } else {
            return -1; // Компьютер победил
        }
    }
}
