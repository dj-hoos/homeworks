import java.util.Scanner;

public class FactorialCalculator {

    // Метод для вычисления факториала числа с использованием рекурсии
    public static long calculateFactorial(int n) {
        // Базовый случай: факториал 0 равен 1
        if (n == 0) {
            return 1;
        }
        // Рекурсивный случай: факториал n равен n * факториал (n - 1)
        return n * calculateFactorial(n - 1);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите число n для вычисления факториала: ");
        int n = scanner.nextInt();

        if (n < 0) {
            System.out.println("Факториал отрицательного числа не определен.");
        } else {
            long factorial = calculateFactorial(n);
            System.out.println(n + "! = " + factorial);
        }

    }
}
