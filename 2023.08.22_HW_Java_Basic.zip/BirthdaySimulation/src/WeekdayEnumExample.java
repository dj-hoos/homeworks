import java.util.Scanner;

public class WeekdayEnumExample {
    //https://javarush.com/groups/posts/1963-kak-ispoljhzovatjh-klass-enum

    public enum DayOfWeek {
        MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите имя текущего дня недели: ");
        String currentDayName = scanner.nextLine().toUpperCase();

        try {
            DayOfWeek currentDay = DayOfWeek.valueOf(currentDayName);

            System.out.println("Дни недели, кроме " + currentDay + ":");

            for (DayOfWeek day : DayOfWeek.values()) {
                if (day != currentDay) {
                    System.out.println(day);
                }
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Некорректное имя дня недели.");
        }
    }
}
