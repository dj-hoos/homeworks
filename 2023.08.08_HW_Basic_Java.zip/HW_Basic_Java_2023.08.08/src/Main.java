import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();

        //Тут генерация происходит из всего, что может нести в себе тип.
        byte byteValue = (byte) random.nextInt(Byte.MAX_VALUE + 1);
        short shortValue = (short) random.nextInt(Short.MAX_VALUE + 1);
        int intValue = random.nextInt();
        long longValue = random.nextLong();
        float floatValue = random.nextFloat();
        double doubleValue = random.nextDouble();

        // тут рандомно генерируется буква от а до с.
        char charValue = (char) (random.nextInt(3) + 'a');
        // значение "боунд" определяет из скольки букв алфавита будет генерироваться результат

        boolean booleanValue = random.nextBoolean();
        //Юрий, мне тут непонятно как сделать так, чтобы значение было фолс.
        //Напишите, пожалуйста, как это сделать.


        int rndNum = (int) (Math.random() * 100);
        String generatedString = String.valueOf(rndNum);



        // тут выводим все это на экран
        System.out.println();
        //System.out.println();
        //System.out.println();
        System.out.println("byteValue: " + byteValue);
        System.out.println("shortValue: " + shortValue);
        System.out.println("intValue: " + intValue);
        System.out.println("longValue: " + longValue);
        System.out.println("floatValue: " + floatValue);
        System.out.println("doubleValue: " + doubleValue);
        System.out.println("charValue: " + charValue);
        System.out.println("booleanValue: " + booleanValue);
        System.out.println();
        System.out.println("__________");
        System.out.println("Стринги :) " + generatedString);
    }
}
