import java.util.Scanner;

public class WeddingAnniversary {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите количество лет в браке: ");
        int yearsMarried = scanner.nextInt();

        String[] anniversaryNames = {
                "Бумажная", "Ситцевая", "Кожаная", "Чугунная", "Деревянная",
                "Железная", "Медная", "Бронзовая", "Серебряная", "Золотая",
                "Изумрудная", "Бриллиантовая", "Стальная", "Лазурная", "Рубиновая"
        };

        int nextAnniversaryIndex = yearsMarried - 1;
        if (nextAnniversaryIndex >= 0 && nextAnniversaryIndex < anniversaryNames.length) {
            String nextAnniversary = anniversaryNames[nextAnniversaryIndex];
            System.out.println("Следующая годовщина свадьбы будет " + nextAnniversary + ".");
        } else {
            System.out.println("Извините, для такого количества лет в браке нет известной годовщины.");
        }
    }
}
