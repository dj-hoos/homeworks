import java.util.Random;
import java.util.Scanner;

public class MultiplicationQuiz {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int num1 = random.nextInt(9) + 1; // Генерация первого числа от 1 до 9
        int num2 = random.nextInt(9) + 1; // Генерация второго числа от 1 до 9

        System.out.println("Пожалуйста, решите задачу:");
        System.out.print(num1 + " * " + num2 + " = ");

        int userAnswer = scanner.nextInt();
        int correctAnswer = num1 * num2;

        if (userAnswer == correctAnswer) {
            System.out.println("Правильно!");
        } else {
            System.out.println("Неправильно. Правильный ответ: " + correctAnswer);
        }
    }
}
