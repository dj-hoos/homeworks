public class yandex {
    public static void main(String[] args) {
        String string ="AAAAABBBBCCDEEEEEFFFFGGHLLLLMMMNNN";
        System.out.println(letterСount(string));


    }

    public static String letterСount (String str) {
        if (str == null || str.equals("")) {
            return str;
        }
        char curentChar = str.charAt(0);
        int curentCharCount = 1;
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= str.length(); i++) {
            char c = (i < str.length() ? str.charAt(i) : 0);
            if (i == str.length() || curentCharCount == str.length() || c != curentChar) {
                sb.append(curentChar);
                if (curentCharCount > 1) {
                    sb.append((char) (curentCharCount + '0'));
                }
                curentCharCount = 1;
                curentChar = c;
            } else {
                curentCharCount++;
            }
        }
        return sb.toString();
    }
}
