public class Main {
    public static void main(String[] args) {
        /*Задача: Васе 10 полных лет, Коле - 12, Кате и Тоне - 13, Боре - 15. Создайте переменные для хранения возрастов ребят*/

        //Чтобы создать переменную, нужно:
        //1 подумать, какого типа будет переменная. Придумать уникальное имя
        int vasyaAge; //Моя переменная будет хранить целые числа (полных лет). По условиям задачи подойдёт любой целочисленный тип - byte, short, int, long. int привычнее

        //присвоить (назначить) переменной значение
        vasyaAge = 10; // Васин возраст по задаче равен 10, присваиваю это значение

        //далее мы можем брать значение переменной множество раз
        System.out.println("Васин возраст - " + vasyaAge + " лет"); //Строки можно объединять друг с другом и с другими переменными с помощью знака "+". В результате всегда будет новая строка

        //Кроме того, значение переменной можно изменить
        vasyaAge = 10 + 1;
        System.out.println("Вася повзрослел. Теперь его возраст - " + vasyaAge + " лет");

        //Создадим ещё одну переменную для возраста Коли
        int kolyaAge = 12; //Значение переменной можно присвоить сразу
        System.out.println("Колин возраст - " + kolyaAge + " лет");

        //Создадим две переменных для возраста Кати и Тони
        int katyaAge, tonyaAge; //можно объявить сразу две переменных одного типа. На практике так лучше не делать
        katyaAge = tonyaAge = 13; //присваивание выполняется справа налево, поэтому в tonyaAge запишется 13, затем katyaAge присвоится возраст tonyaAge
        System.out.println("Катин возраст - " + katyaAge + " лет");
        System.out.println("Тонин возраст - " + tonyaAge + " лет");

        //Если мы изменим возраст одной из девочек, то возраст другой НЕ изменится, т.е. переменные не связаны. Это справедливо только для примитивных типов (byte, short, int, long, char, boolean, double, float) и строк
        tonyaAge = 14;
        System.out.println("Тоня подросла. Её возраст - " + tonyaAge + " лет");
        System.out.println("Катин возраст остался прежним - " + katyaAge + " лет");

        //Иногда переменную нужно изменить относительно её текущего значения (например, увеличить или уменьшить на 1).
        katyaAge = katyaAge + 1; //Сначала компилятор возьмёт число 1, потом добавит к нему текущее значение переменной tonyaAge (14). Полученное значение (15) запишет в переменную tonyaAge
        System.out.println("Вот и Катя выросла. Ей - " + katyaAge + " лет");

        //Создайте переменную для хранения возраста Бори, выведите сообщение с возрастом с помощью System.out.println()
        int borjaAge = 15;
        System.out.println("<Борин> возраст - " + borjaAge + " лет");



        //Ой, я ошибся! Боре всего 14. Уменьшите возраст Бори в переменной на 1 и выведите новое сообщение с возрастом

        borjaAge = borjaAge - 1;
        System.out.println("Теперь <Борин> возраст - " + borjaAge + " лет");


        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();


        // Символьные значения
        char person_sex = 'm';

        //Целочисленные
        byte person_age = 25;
        short registry_number = 15075;
        int passport_id = 361287;
        long phone_number = 90357887;

        //С плавающей точкой
        double Human_weight = 85.400;
        float Human_height = 186.3F;

        System.out.println("Пол человека - " + person_sex + ", Ему " + person_age + " лет");
        System.out.println("Номер паспорта - " + passport_id + ", Номер регистрации в системе " + registry_number + ", Номер телефона: " + phone_number);
        System.out.println("Вес: - " + Human_weight + ", Рост " + Human_height);



        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();


        int number = 345;

        while (number > 0) {
            System.out.println (number % 10);
            number = number / 10;
        }






        

    }
}
