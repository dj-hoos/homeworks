import java.util.Scanner;

public class ClosestTo10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число m: ");
        double m = scanner.nextDouble();

        System.out.print("Введите число n: ");
        double n = scanner.nextDouble();

        String result = closestTo10(m, n);
        System.out.println(result);
    }

    public static String closestTo10(double m, double n) {
        double distanceM = Math.abs(10 - m);
        double distanceN = Math.abs(10 - n);

        if (distanceM < distanceN) {
            return "Число " + m + " ближе к 10.";
        } else if (distanceN < distanceM) {
            return "Число " + n + " ближе к 10.";
        } else {
            return "Оба числа на одинаковом расстоянии от 10.";
        }
    }
}
