import java.util.Scanner;
public class Division {
     public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
         System.out.print("Введите любое целое число - ");
         int numberA = scanner.nextInt();
         System.out.println("Число после деления на 2 без остатка - " + (numberA>>1));

         //Пользователь вводит целое число. Напишите программу,
         // которая делит это число на 2 и выводит результат.
         // Остаток деления можно отбросить.
         // Операторы деления / и остатка от деления % применять нельзя.




        }
}



