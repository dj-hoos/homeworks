import java.util.Scanner;

public class ElvisYears {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите год: ");
        int year = scanner.nextInt();

        String message = (year < 1935) ? "Элвис ещё не родился" :
                (year >= 1935 && year <= 1977) ? "Элвис жив!" :
                        "Элвис навсегда в наших сердцах!";

        System.out.println(message);
    }
}
