import java.util.Scanner;

public class LengthConverter {
    public static void main(String[] args) {

        //Дана длина в метрах. Напишите программу, которая переводит указанное значение в
        // км, мили, футы и аршины. Выведите начальное и конвертированные значения на экран

        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите длину в метрах: ");
        double lengthInMeters = scanner.nextDouble();
        double kilometers = lengthInMeters / 1000;
        double miles = lengthInMeters * 0.000621371;
        double feet = lengthInMeters * 3.28084;
        double arshins = lengthInMeters * 1.40607424;

        System.out.println("Длина в метрах: " + lengthInMeters + " м");
        System.out.println("Длина в километрах: " + kilometers + " км");
        System.out.println("Длина в милях: " + miles + " миль");
        System.out.println("Длина в футах: " + feet + " фт");
        System.out.println("Длина в аршинах: " + arshins + " аршинов");


    }
}
