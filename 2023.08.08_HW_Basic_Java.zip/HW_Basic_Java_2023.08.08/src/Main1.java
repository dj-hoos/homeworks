

import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        //Это метод, который сканирует нажатия на клаву.

        //дальше из сканера записываем полученные данные в соответствующие переменные..
        System.out.print("Введите ваше имя: ");
        String name = scanner.nextLine();

        System.out.print("Введите ваш возраст (полных лет): ");
        int age = scanner.nextInt();

        System.out.print("Введите ваш вес: ");
        double weight = scanner.nextDouble();


        System.out.println();
        System.out.println("Уважаемый, " + name + "! В свои " + age + " лет Вы для нас дороги, как " + weight + " килограмм золота.");
        System.out.println();
        System.out.println("А теперь на Немецком языке");
        System.out.println();
        System.out.println("Liebe, " + name + "! Mit " + age + " bist du für uns so wertvoll wie " + weight + " Kilogramm Gold.");
    }
}
