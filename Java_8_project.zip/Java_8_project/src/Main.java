public class Main {
    public static void main(String[] args) {
        int x = 2;
        int y = 3;
        System.out.println(x+y);
        System.out.println(x-y);
        System.out.println(x*y);
        System.out.println(x/y);
    }
}
