import java.util.Scanner;

public class ChangeCalculator
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите сумму покупок (в рублях и копейках): ");
        double totalCost = scanner.nextDouble();

        System.out.print("Введите сумму денег, которую дал покупатель (в рублях и копейках): ");
        double amountGiven = scanner.nextDouble();

        double change = amountGiven - totalCost;

        int rubles = (int) change;
        int kopeks = (int) Math.round((change - rubles) * 100);

        System.out.println("Сдача составляет: " + rubles + " рублей и " + kopeks + " копеек");

        //Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
        // которую дал покупатель. Выведите сумму сдачи в виде “X рублей и Y копеек”

    }
}
