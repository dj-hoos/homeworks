import java.util.Scanner;

public class WeddingAnniversaryCalculator {
    // Создаем Enum для годовщин свадьбы


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите количество лет в браке: ");

        if (scanner.hasNextInt()) {
            int yearsInMarriage = scanner.nextInt();

            // Вычисляем годовщину на основе введенных лет
            WeddingAnniversary anniversary;
            switch (yearsInMarriage) {
                case 1:
                    anniversary = WeddingAnniversary.БУМАЖНАЯ;
                    break;
                case 2:
                    anniversary = WeddingAnniversary.СИТЦЕВАЯ;
                    break;
                case 3:
                    anniversary = WeddingAnniversary.ЧУГУННАЯ;
                    break;
                case 25:
                    anniversary = WeddingAnniversary.СЕРЕБРЯНАЯ;
                    break;
                case 50:
                    anniversary = WeddingAnniversary.ЗОЛОТАЯ;
                    break;
                default:
                    anniversary = null;
                    break;
            }

            if (anniversary != null) {
                System.out.println("Ваша следующая годовщина свадьбы будет " + anniversary + "!");
            } else {
                System.out.println("К сожалению, для " + yearsInMarriage + " лет в браке нет специальной годовщины.");
            }
        } else {
            System.out.println("Некорректный ввод. Пожалуйста, введите число лет в браке.");
        }

        scanner.close();
    }
}
