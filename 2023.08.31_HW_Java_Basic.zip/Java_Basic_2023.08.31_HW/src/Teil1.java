import java.util.Arrays;

public class Teil1 {
    public static void main(String[] args) {

        char[][] alphabet = new char[6][6];
        char letter = 'А';
        for (char i = 0; i < alphabet.length; i++) {
            for (char j = 0; j < alphabet[i].length; j++) {
                if (letter == 'Ж') {
                    letter = 'Ё';
                }
                alphabet[i][j] = letter;
                if (letter == 'Ђ') {
                    letter = 'Ж';
                }
                alphabet[i][j] = letter;
                letter++;
                if (letter == 'Я' + 1) {
                    break;
                }
            }
        }
        System.out.println(Arrays.deepToString(alphabet));
    }
}
