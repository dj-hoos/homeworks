import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите число 1: ");
        int number1 = scanner.nextInt();
        System.out.print("Введите число 2: ");
        int number2 = scanner.nextInt();

        // Делаю вычисления
        int pluss = number1 + number2;
        int minuss = number1 - number2;
        int umnojit = number1 * number2;
        double delenie = (double) number1 / number2; // Делаю double для точности

        // Результат
        System.out.println("Плюс: " + pluss);
        System.out.println("Минус: " + minuss);
        System.out.println("Умножение: " + umnojit);
        System.out.println("Деление: " + delenie);

        
    }
}
