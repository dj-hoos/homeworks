public class StringArrayManipulation {

    public static void main(String[] args) {
        String[] stringArray = new String[5];

        // Заполняем массив строками
        stringArray[0] = "Это строка 1";
        stringArray[1] = "Короткая строка";
        stringArray[2] = "Средняя строка";
        stringArray[3] = "Длинная строка с большим количеством символов";
        stringArray[4] = "Еще одна средняя строка";

        // Ищем строку с наибольшей и наименьшей длиной
        String shortestString = stringArray[0];
        String longestString = stringArray[0];

        for (String str : stringArray) {
            if (str.length() < shortestString.length()) {
                shortestString = str;
            }
            if (str.length() > longestString.length()) {
                longestString = str;
            }
        }

        // Выводим массив строк на консоль
        System.out.println("Массив строк:");
        for (String str : stringArray) {
            System.out.println(str);
        }
        System.out.println();
        System.out.println();
        System.out.println("_______________________");

        // Выводим строки с наименьшей и наибольшей длиной на консоль
        System.out.println("Строка с наименьшей длиной: " + shortestString);
        System.out.println("Строка с наибольшей длиной: " + longestString);
    }
}
