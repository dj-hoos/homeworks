import java.time.LocalDate;
import java.util.Arrays;

public class DateSorting {
    public static void main(String[] args) {
        // Создаю массив из 8 элементов с датами
        LocalDate[] dates = new LocalDate[8];
        dates[0] = LocalDate.of(2023, 1, 15);
        dates[1] = LocalDate.of(2022, 4, 20);
        dates[2] = LocalDate.of(2023, 3, 5);
        dates[3] = LocalDate.of(2021, 11, 10);
        dates[4] = LocalDate.of(2022, 7, 8);
        dates[5] = LocalDate.of(2021, 9, 30);
        dates[6] = LocalDate.of(2022, 2, 1);
        dates[7] = LocalDate.of(2023, 6, 25);

        // 2. Сортируем массив дат по году
        sortByYear(dates);
        System.out.println();

        // Выводим отсортированный массив
        System.out.println("Массив отсортированный по году:");
        printDates(dates);
        System.out.println();

        // 3. Сортируем массив дат по дню месяца
        sortByDayOfMonth(dates);

        // Выводим отсортированный массив
        System.out.println("Массив отсортированный по дню месяца:");
        printDates(dates);
        System.out.println();
    }

    // Метод для сортировки массива дат по году
    public static void sortByYear(LocalDate[] dates) {
        Arrays.sort(dates, (date1, date2) -> date1.getYear() - date2.getYear());
    }

    // Метод для сортировки массива дат по дню месяца
    public static void sortByDayOfMonth(LocalDate[] dates) {
        Arrays.sort(dates, (date1, date2) -> date1.getDayOfMonth() - date2.getDayOfMonth());
    }

    // Метод для вывода массива дат в консоль
    public static void printDates(LocalDate[] dates) {
        for (LocalDate date : dates) {
            System.out.println(date);
        }
    }
}
