public class MultiplicationExample {

    // Метод для перемножения двух чисел
    public static int multiply(int a, int b) {
        return a * b;
    }

    // Метод для перемножения трех чисел, использующий метод для двух чисел
    public static int multiply(int a, int b, int c) {
        int result = multiply(a, b); // Вызываем метод для двух чисел
        return result * c;
    }

    // Метод для перемножения четырех чисел, использующий метод для трех чисел
    public static int multiply(int a, int b, int c, int d) {
        int result = multiply(a, b, c); // Вызываем метод для трех чисел
        return result * d;
    }

    public static void main(String[] args) {
        int result2 = multiply(2, 3);
        System.out.println("Результат умножения двух чисел: " + result2);

        int result3 = multiply(2, 3, 4);
        System.out.println("Результат умножения трех чисел: " + result3);

        int result4 = multiply(2, 3, 4, 5);
        System.out.println("Результат умножения четырех чисел: " + result4);
    }
}
