import java.time.LocalDate;
import java.util.Arrays;


public class Main {

    public static void main(String[] args) {

        System.out.println();
        LocalDate date = LocalDate.of(2020, 8, 4);

        // 1. Создаем массив из 8 элементов с датами
        LocalDate[] dates = {
                LocalDate.of(2022, 7, 3),
                LocalDate.of(2021, 9, 9),
                LocalDate.of(2020, 12, 30),
                LocalDate.of(2019, 1, 21),
                LocalDate.of(2018, 8, 15),
                LocalDate.of(2017, 6, 6),
                LocalDate.of(2016, 7, 2),
                LocalDate.of(2015, 3, 12),
        };
        System.out.println(Arrays.toString(dates));
        sortYear(dates);
        System.out.println(Arrays.toString(dates));
        sortDay(dates);
        System.out.println(Arrays.toString(dates));


    }
    private static void sValues(LocalDate[] dates, int a, int b) {
        LocalDate temp = dates[a];
        dates[a] = dates[b];
        dates[b] = temp;

    }
    // Метод для сортировки массива дат по году
    public static void sortYear(LocalDate[] dates) {
        boolean isSorted = false;
        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i < dates.length - 1; i++) {
                if (dates[i].getYear() > dates[i + 1].getYear()) {
                    sValues(dates, i, i + 1);
                    isSorted = false;
                }
            }
        }
    }

    // Метод для сортировки массива дат по дню месяца
    public static void sortDay(LocalDate[] dates) {
        boolean isSorted = false;
        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i < dates.length - 1; i++) {
                if (dates[i].getDayOfMonth() > dates[i + 1].getDayOfMonth()) {

                    sValues(dates, i, i + 1);
                    isSorted = false;
                }
            }
        }
    }
}