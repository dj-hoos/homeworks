import java.util.Random;

public class BirthdaySimulation {

    public static void main(String[] args) {
        int targetAmount = 10000;
        int computerPrice = 10000;
        simulateBirthdayGifts(targetAmount, computerPrice);
    }

    public static void simulateBirthdayGifts(int targetAmount, int computerPrice) {
        int collectedAmount = 0;
        int[] denominations = {50, 100, 200, 500};
        int[] giftCount = new int[4];

        Random random = new Random();

        while (collectedAmount < targetAmount) {
            int friendGift = denominations[random.nextInt(4)];
            giftCount[getDenominationIndex(friendGift)]++;
            collectedAmount += friendGift;
            System.out.println("Друг подарил тебе " + friendGift + " долларов. Собрано всего: " + collectedAmount + " долларов.");
        }

        System.out.println("\nПоздравляю! Собрана необходимая сумма для игрового компьютера!");
        System.out.println("Список подарков от друзей:");
        for (int i = 0; i < denominations.length; i++) {
            if (giftCount[i] > 0) {
                System.out.println(giftCount[i] + " купюр по " + denominations[i] + " долларов");
            }
        }

        if (collectedAmount > computerPrice) {
            System.out.println("\nУра! У нас есть даже чуть больше, чем нужно! Время пойти в бар!");
        } else {
            System.out.println("\nДрузья, мы собрали деньги на игровой компьютер! Пойдем в бар!");
        }
    }

    public static int getDenominationIndex(int denomination) {
        return switch (denomination) {
            case 50 -> 0;
            case 100 -> 1;
            case 200 -> 2;
            case 500 -> 3;
            default -> -1;
        };
    }
}
